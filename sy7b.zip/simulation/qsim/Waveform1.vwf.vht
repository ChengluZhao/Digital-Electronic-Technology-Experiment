-- Copyright (C) 2017  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Intel and sold by Intel or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- *****************************************************************************
-- This file contains a Vhdl test bench with test vectors .The test vectors     
-- are exported from a vector file in the Quartus Waveform Editor and apply to  
-- the top level entity of the current Quartus project .The user can use this   
-- testbench to simulate his design using a third-party simulation tool .       
-- *****************************************************************************
-- Generated on "05/23/2024 22:30:54"
                                                             
-- Vhdl Test Bench(with test vectors) for design  :          fenpin10
-- 
-- Simulation tool : 3rd Party
-- 

LIBRARY ieee;                                               
USE ieee.std_logic_1164.all;                                

ENTITY fenpin10_vhd_vec_tst IS
END fenpin10_vhd_vec_tst;
ARCHITECTURE fenpin10_arch OF fenpin10_vhd_vec_tst IS
-- constants                                                 
-- signals                                                   
SIGNAL CLK_SOURCE : STD_LOGIC;
SIGNAL CLK_TARGET : STD_LOGIC;
SIGNAL CLR : STD_LOGIC;
COMPONENT fenpin10
	PORT (
	CLK_SOURCE : IN STD_LOGIC;
	CLK_TARGET : OUT STD_LOGIC;
	CLR : IN STD_LOGIC
	);
END COMPONENT;
BEGIN
	i1 : fenpin10
	PORT MAP (
-- list connections between master ports and signals
	CLK_SOURCE => CLK_SOURCE,
	CLK_TARGET => CLK_TARGET,
	CLR => CLR
	);

-- CLK_SOURCE
t_prcs_CLK_SOURCE: PROCESS
BEGIN
LOOP
	CLK_SOURCE <= '0';
	WAIT FOR 5000 ps;
	CLK_SOURCE <= '1';
	WAIT FOR 5000 ps;
	IF (NOW >= 1000000 ps) THEN WAIT; END IF;
END LOOP;
END PROCESS t_prcs_CLK_SOURCE;

-- CLR
t_prcs_CLR: PROCESS
BEGIN
	CLR <= '1';
WAIT;
END PROCESS t_prcs_CLR;
END fenpin10_arch;
