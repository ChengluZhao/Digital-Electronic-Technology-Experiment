-- Copyright (C) 2017  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Intel and sold by Intel or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 17.0.0 Build 595 04/25/2017 SJ Lite Edition"

-- DATE "05/23/2024 22:30:55"

-- 
-- Device: Altera 5CSEMA5F31C6 Package FBGA896
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY ALTERA_LNSIM;
LIBRARY CYCLONEV;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE ALTERA_LNSIM.ALTERA_LNSIM_COMPONENTS.ALL;
USE CYCLONEV.CYCLONEV_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	fenpin10 IS
    PORT (
	CLR : IN std_logic;
	CLK_SOURCE : IN std_logic;
	CLK_TARGET : OUT std_logic
	);
END fenpin10;

-- Design Ports Information
-- CLK_TARGET	=>  Location: PIN_AE23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- CLK_SOURCE	=>  Location: PIN_Y27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- CLR	=>  Location: PIN_AG25,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF fenpin10 IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_CLR : std_logic;
SIGNAL ww_CLK_SOURCE : std_logic;
SIGNAL ww_CLK_TARGET : std_logic;
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \CLK_SOURCE~input_o\ : std_logic;
SIGNAL \CLK_SOURCE~inputCLKENA0_outclk\ : std_logic;
SIGNAL \CLR~input_o\ : std_logic;
SIGNAL \CNT~0_combout\ : std_logic;
SIGNAL \CNT~2_combout\ : std_logic;
SIGNAL \CNT[0]~DUPLICATE_q\ : std_logic;
SIGNAL \CNT[1]~1_combout\ : std_logic;
SIGNAL \CNT[1]~DUPLICATE_q\ : std_logic;
SIGNAL \CNT[2]~DUPLICATE_q\ : std_logic;
SIGNAL \TMP~0_combout\ : std_logic;
SIGNAL \TMP~q\ : std_logic;
SIGNAL CNT : std_logic_vector(2 DOWNTO 0);
SIGNAL \ALT_INV_TMP~q\ : std_logic;
SIGNAL ALT_INV_CNT : std_logic_vector(2 DOWNTO 0);
SIGNAL \ALT_INV_CNT[1]~DUPLICATE_q\ : std_logic;
SIGNAL \ALT_INV_CNT[2]~DUPLICATE_q\ : std_logic;
SIGNAL \ALT_INV_CNT[0]~DUPLICATE_q\ : std_logic;

BEGIN

ww_CLR <= CLR;
ww_CLK_SOURCE <= CLK_SOURCE;
CLK_TARGET <= ww_CLK_TARGET;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
\ALT_INV_TMP~q\ <= NOT \TMP~q\;
ALT_INV_CNT(2) <= NOT CNT(2);
ALT_INV_CNT(1) <= NOT CNT(1);
ALT_INV_CNT(0) <= NOT CNT(0);
\ALT_INV_CNT[1]~DUPLICATE_q\ <= NOT \CNT[1]~DUPLICATE_q\;
\ALT_INV_CNT[2]~DUPLICATE_q\ <= NOT \CNT[2]~DUPLICATE_q\;
\ALT_INV_CNT[0]~DUPLICATE_q\ <= NOT \CNT[0]~DUPLICATE_q\;

-- Location: IOOBUF_X78_Y0_N19
\CLK_TARGET~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \TMP~q\,
	devoe => ww_devoe,
	o => ww_CLK_TARGET);

-- Location: IOIBUF_X89_Y25_N21
\CLK_SOURCE~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CLK_SOURCE,
	o => \CLK_SOURCE~input_o\);

-- Location: CLKCTRL_G10
\CLK_SOURCE~inputCLKENA0\ : cyclonev_clkena
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	disable_mode => "low",
	ena_register_mode => "always enabled",
	ena_register_power_up => "high",
	test_syn => "high")
-- pragma translate_on
PORT MAP (
	inclk => \CLK_SOURCE~input_o\,
	outclk => \CLK_SOURCE~inputCLKENA0_outclk\);

-- Location: IOIBUF_X78_Y0_N35
\CLR~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CLR,
	o => \CLR~input_o\);

-- Location: FF_X78_Y1_N31
\CNT[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK_SOURCE~inputCLKENA0_outclk\,
	d => \CNT[1]~1_combout\,
	clrn => \CLR~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => CNT(1));

-- Location: FF_X78_Y1_N59
\CNT[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK_SOURCE~inputCLKENA0_outclk\,
	d => \CNT~2_combout\,
	clrn => \CLR~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => CNT(0));

-- Location: MLABCELL_X78_Y1_N15
\CNT~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \CNT~0_combout\ = ( CNT(2) & ( CNT(1) & ( !CNT(0) ) ) ) # ( !CNT(2) & ( CNT(1) & ( CNT(0) ) ) ) # ( CNT(2) & ( !CNT(1) & ( CNT(0) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011110000111100001111000011111111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => ALT_INV_CNT(0),
	datae => ALT_INV_CNT(2),
	dataf => ALT_INV_CNT(1),
	combout => \CNT~0_combout\);

-- Location: FF_X78_Y1_N17
\CNT[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK_SOURCE~inputCLKENA0_outclk\,
	d => \CNT~0_combout\,
	clrn => \CLR~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => CNT(2));

-- Location: MLABCELL_X78_Y1_N57
\CNT~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \CNT~2_combout\ = ( !CNT(0) & ( CNT(1) ) ) # ( !CNT(0) & ( !CNT(1) & ( !CNT(2) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000000000000000000011111111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => ALT_INV_CNT(2),
	datae => ALT_INV_CNT(0),
	dataf => ALT_INV_CNT(1),
	combout => \CNT~2_combout\);

-- Location: FF_X78_Y1_N58
\CNT[0]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK_SOURCE~inputCLKENA0_outclk\,
	d => \CNT~2_combout\,
	clrn => \CLR~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \CNT[0]~DUPLICATE_q\);

-- Location: MLABCELL_X78_Y1_N30
\CNT[1]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \CNT[1]~1_combout\ = ( !CNT(1) & ( \CNT[0]~DUPLICATE_q\ ) ) # ( CNT(1) & ( !\CNT[0]~DUPLICATE_q\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111111111111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => ALT_INV_CNT(1),
	dataf => \ALT_INV_CNT[0]~DUPLICATE_q\,
	combout => \CNT[1]~1_combout\);

-- Location: FF_X78_Y1_N32
\CNT[1]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK_SOURCE~inputCLKENA0_outclk\,
	d => \CNT[1]~1_combout\,
	clrn => \CLR~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \CNT[1]~DUPLICATE_q\);

-- Location: FF_X78_Y1_N16
\CNT[2]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK_SOURCE~inputCLKENA0_outclk\,
	d => \CNT~0_combout\,
	clrn => \CLR~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \CNT[2]~DUPLICATE_q\);

-- Location: MLABCELL_X78_Y1_N48
\TMP~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \TMP~0_combout\ = ( \TMP~q\ & ( \CNT[2]~DUPLICATE_q\ & ( (CNT(0)) # (\CNT[1]~DUPLICATE_q\) ) ) ) # ( !\TMP~q\ & ( \CNT[2]~DUPLICATE_q\ & ( (!\CNT[1]~DUPLICATE_q\ & !CNT(0)) ) ) ) # ( \TMP~q\ & ( !\CNT[2]~DUPLICATE_q\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111111001100000000000011001111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_CNT[1]~DUPLICATE_q\,
	datad => ALT_INV_CNT(0),
	datae => \ALT_INV_TMP~q\,
	dataf => \ALT_INV_CNT[2]~DUPLICATE_q\,
	combout => \TMP~0_combout\);

-- Location: FF_X78_Y1_N49
TMP : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK_SOURCE~inputCLKENA0_outclk\,
	d => \TMP~0_combout\,
	clrn => \CLR~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \TMP~q\);

-- Location: MLABCELL_X39_Y37_N3
\~QUARTUS_CREATED_GND~I\ : cyclonev_lcell_comb
-- Equation(s):

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
;
END structure;


