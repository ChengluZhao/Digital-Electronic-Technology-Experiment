-- Copyright (C) 2017  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Intel and sold by Intel or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- *****************************************************************************
-- This file contains a Vhdl test bench with test vectors .The test vectors     
-- are exported from a vector file in the Quartus Waveform Editor and apply to  
-- the top level entity of the current Quartus project .The user can use this   
-- testbench to simulate his design using a third-party simulation tool .       
-- *****************************************************************************
-- Generated on "06/05/2024 22:18:31"
                                                             
-- Vhdl Test Bench(with test vectors) for design  :          shiwei
-- 
-- Simulation tool : 3rd Party
-- 

LIBRARY ieee;                                               
USE ieee.std_logic_1164.all;                                

ENTITY shiwei_vhd_vec_tst IS
END shiwei_vhd_vec_tst;
ARCHITECTURE shiwei_arch OF shiwei_vhd_vec_tst IS
-- constants                                                 
-- signals                                                   
SIGNAL A : STD_LOGIC;
SIGNAL BI : STD_LOGIC;
SIGNAL LT : STD_LOGIC;
SIGNAL Q : STD_LOGIC_VECTOR(6 DOWNTO 0);
SIGNAL RBI : STD_LOGIC;
COMPONENT shiwei
	PORT (
	A : IN STD_LOGIC;
	BI : IN STD_LOGIC;
	LT : IN STD_LOGIC;
	Q : OUT STD_LOGIC_VECTOR(6 DOWNTO 0);
	RBI : IN STD_LOGIC
	);
END COMPONENT;
BEGIN
	i1 : shiwei
	PORT MAP (
-- list connections between master ports and signals
	A => A,
	BI => BI,
	LT => LT,
	Q => Q,
	RBI => RBI
	);

-- A
t_prcs_A: PROCESS
BEGIN
	A <= '0';
	WAIT FOR 10000 ps;
	A <= '1';
	WAIT FOR 10000 ps;
	A <= '0';
WAIT;
END PROCESS t_prcs_A;

-- BI
t_prcs_BI: PROCESS
BEGIN
	BI <= '1';
WAIT;
END PROCESS t_prcs_BI;

-- LT
t_prcs_LT: PROCESS
BEGIN
	LT <= '1';
WAIT;
END PROCESS t_prcs_LT;

-- RBI
t_prcs_RBI: PROCESS
BEGIN
	RBI <= '1';
WAIT;
END PROCESS t_prcs_RBI;
END shiwei_arch;
