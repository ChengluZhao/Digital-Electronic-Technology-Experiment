-- Copyright (C) 2017  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Intel and sold by Intel or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- *****************************************************************************
-- This file contains a Vhdl test bench with test vectors .The test vectors     
-- are exported from a vector file in the Quartus Waveform Editor and apply to  
-- the top level entity of the current Quartus project .The user can use this   
-- testbench to simulate his design using a third-party simulation tool .       
-- *****************************************************************************
-- Generated on "06/17/2024 23:06:59"
                                                             
-- Vhdl Test Bench(with test vectors) for design  :          zong
-- 
-- Simulation tool : 3rd Party
-- 

LIBRARY ieee;                                               
USE ieee.std_logic_1164.all;                                

ENTITY zong_vhd_vec_tst IS
END zong_vhd_vec_tst;
ARCHITECTURE zong_arch OF zong_vhd_vec_tst IS
-- constants                                                 
-- signals                                                   
SIGNAL CP : STD_LOGIC;
SIGNAL GW : STD_LOGIC_VECTOR(6 DOWNTO 0);
SIGNAL QL : STD_LOGIC;
SIGNAL SW : STD_LOGIC_VECTOR(6 DOWNTO 0);
SIGNAL SXW : STD_LOGIC_VECTOR(6 DOWNTO 0);
COMPONENT zong
	PORT (
	CP : IN STD_LOGIC;
	GW : OUT STD_LOGIC_VECTOR(6 DOWNTO 0);
	QL : IN STD_LOGIC;
	SW : OUT STD_LOGIC_VECTOR(6 DOWNTO 0);
	SXW : OUT STD_LOGIC_VECTOR(6 DOWNTO 0)
	);
END COMPONENT;
BEGIN
	i1 : zong
	PORT MAP (
-- list connections between master ports and signals
	CP => CP,
	GW => GW,
	QL => QL,
	SW => SW,
	SXW => SXW
	);

-- CP
t_prcs_CP: PROCESS
BEGIN
LOOP
	CP <= '0';
	WAIT FOR 10000 ps;
	CP <= '1';
	WAIT FOR 10000 ps;
	IF (NOW >= 1000000 ps) THEN WAIT; END IF;
END LOOP;
END PROCESS t_prcs_CP;

-- QL
t_prcs_QL: PROCESS
BEGIN
	QL <= '1';
WAIT;
END PROCESS t_prcs_QL;
END zong_arch;
