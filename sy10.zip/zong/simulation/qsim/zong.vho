-- Copyright (C) 2017  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Intel and sold by Intel or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 17.0.0 Build 595 04/25/2017 SJ Lite Edition"

-- DATE "06/17/2024 23:07:00"

-- 
-- Device: Altera 5CSEMA5F31C6 Package FBGA896
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY ALTERA_LNSIM;
LIBRARY CYCLONEV;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE ALTERA_LNSIM.ALTERA_LNSIM_COMPONENTS.ALL;
USE CYCLONEV.CYCLONEV_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	zong IS
    PORT (
	GW : OUT std_logic_vector(6 DOWNTO 0);
	QL : IN std_logic;
	CP : IN std_logic;
	SW : OUT std_logic_vector(6 DOWNTO 0);
	SXW : OUT std_logic_vector(6 DOWNTO 0)
	);
END zong;

ARCHITECTURE structure OF zong IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_GW : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_QL : std_logic;
SIGNAL ww_CP : std_logic;
SIGNAL ww_SW : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_SXW : std_logic_vector(6 DOWNTO 0);
SIGNAL \GW[6]~output_o\ : std_logic;
SIGNAL \GW[5]~output_o\ : std_logic;
SIGNAL \GW[4]~output_o\ : std_logic;
SIGNAL \GW[3]~output_o\ : std_logic;
SIGNAL \GW[2]~output_o\ : std_logic;
SIGNAL \GW[1]~output_o\ : std_logic;
SIGNAL \GW[0]~output_o\ : std_logic;
SIGNAL \SW[6]~output_o\ : std_logic;
SIGNAL \SW[5]~output_o\ : std_logic;
SIGNAL \SW[4]~output_o\ : std_logic;
SIGNAL \SW[3]~output_o\ : std_logic;
SIGNAL \SW[2]~output_o\ : std_logic;
SIGNAL \SW[1]~output_o\ : std_logic;
SIGNAL \SW[0]~output_o\ : std_logic;
SIGNAL \SXW[6]~output_o\ : std_logic;
SIGNAL \SXW[5]~output_o\ : std_logic;
SIGNAL \SXW[4]~output_o\ : std_logic;
SIGNAL \SXW[3]~output_o\ : std_logic;
SIGNAL \SXW[2]~output_o\ : std_logic;
SIGNAL \SXW[1]~output_o\ : std_logic;
SIGNAL \SXW[0]~output_o\ : std_logic;
SIGNAL \CP~input_o\ : std_logic;
SIGNAL \inst|1~0_combout\ : std_logic;
SIGNAL \inst1|14~0_combout\ : std_logic;
SIGNAL \inst1|14~q\ : std_logic;
SIGNAL \inst1|30~combout\ : std_logic;
SIGNAL \inst1|19~q\ : std_logic;
SIGNAL \inst1|31~combout\ : std_logic;
SIGNAL \inst1|11~q\ : std_logic;
SIGNAL \inst1|7~0_combout\ : std_logic;
SIGNAL \inst1|7~q\ : std_logic;
SIGNAL \QL~input_o\ : std_logic;
SIGNAL \inst10~combout\ : std_logic;
SIGNAL \inst|1~q\ : std_logic;
SIGNAL \inst2|Mux0~0_combout\ : std_logic;
SIGNAL \inst2|Mux1~0_combout\ : std_logic;
SIGNAL \inst2|Mux2~0_combout\ : std_logic;
SIGNAL \inst2|Mux3~0_combout\ : std_logic;
SIGNAL \inst2|Mux4~0_combout\ : std_logic;
SIGNAL \inst2|Mux5~0_combout\ : std_logic;
SIGNAL \inst2|Mux6~0_combout\ : std_logic;
SIGNAL \inst|2~0_combout\ : std_logic;
SIGNAL \inst|2~q\ : std_logic;
SIGNAL \ALT_INV_QL~input_o\ : std_logic;
SIGNAL \inst|ALT_INV_1~q\ : std_logic;
SIGNAL \inst1|ALT_INV_11~q\ : std_logic;
SIGNAL \inst1|ALT_INV_14~q\ : std_logic;
SIGNAL \inst1|ALT_INV_19~q\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux0~0_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux3~0_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux4~0_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux5~0_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \inst1|ALT_INV_7~q\ : std_logic;
SIGNAL \inst|ALT_INV_2~q\ : std_logic;
SIGNAL \ALT_INV_inst10~combout\ : std_logic;

BEGIN

GW <= ww_GW;
ww_QL <= QL;
ww_CP <= CP;
SW <= ww_SW;
SXW <= ww_SXW;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
\ALT_INV_QL~input_o\ <= NOT \QL~input_o\;
\inst|ALT_INV_1~q\ <= NOT \inst|1~q\;
\inst1|ALT_INV_11~q\ <= NOT \inst1|11~q\;
\inst1|ALT_INV_14~q\ <= NOT \inst1|14~q\;
\inst1|ALT_INV_19~q\ <= NOT \inst1|19~q\;
\inst2|ALT_INV_Mux0~0_combout\ <= NOT \inst2|Mux0~0_combout\;
\inst2|ALT_INV_Mux3~0_combout\ <= NOT \inst2|Mux3~0_combout\;
\inst2|ALT_INV_Mux4~0_combout\ <= NOT \inst2|Mux4~0_combout\;
\inst2|ALT_INV_Mux5~0_combout\ <= NOT \inst2|Mux5~0_combout\;
\inst2|ALT_INV_Mux6~0_combout\ <= NOT \inst2|Mux6~0_combout\;
\inst1|ALT_INV_7~q\ <= NOT \inst1|7~q\;
\inst|ALT_INV_2~q\ <= NOT \inst|2~q\;
\ALT_INV_inst10~combout\ <= NOT \inst10~combout\;

\GW[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|ALT_INV_Mux0~0_combout\,
	devoe => ww_devoe,
	o => \GW[6]~output_o\);

\GW[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \GW[5]~output_o\);

\GW[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \GW[4]~output_o\);

\GW[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|ALT_INV_Mux3~0_combout\,
	devoe => ww_devoe,
	o => \GW[3]~output_o\);

\GW[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|ALT_INV_Mux4~0_combout\,
	devoe => ww_devoe,
	o => \GW[2]~output_o\);

\GW[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|ALT_INV_Mux5~0_combout\,
	devoe => ww_devoe,
	o => \GW[1]~output_o\);

\GW[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \GW[0]~output_o\);

\SW[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \SW[6]~output_o\);

\SW[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|ALT_INV_7~q\,
	devoe => ww_devoe,
	o => \SW[5]~output_o\);

\SW[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|ALT_INV_7~q\,
	devoe => ww_devoe,
	o => \SW[4]~output_o\);

\SW[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \SW[3]~output_o\);

\SW[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \SW[2]~output_o\);

\SW[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \SW[1]~output_o\);

\SW[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \SW[0]~output_o\);

\SXW[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \SXW[6]~output_o\);

\SXW[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \SXW[5]~output_o\);

\SXW[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|2~q\,
	devoe => ww_devoe,
	o => \SXW[4]~output_o\);

\SXW[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \SXW[3]~output_o\);

\SXW[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \SXW[2]~output_o\);

\SXW[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \SXW[1]~output_o\);

\SXW[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \SXW[0]~output_o\);

\CP~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CP,
	o => \CP~input_o\);

\inst|1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|1~0_combout\ = !\inst|1~q\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101010101010101010101010101010101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_1~q\,
	combout => \inst|1~0_combout\);

\inst1|14~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst1|14~0_combout\ = !\inst1|11~q\ $ (!\inst1|14~q\)

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0110011001100110011001100110011001100110011001100110011001100110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|ALT_INV_11~q\,
	datab => \inst1|ALT_INV_14~q\,
	combout => \inst1|14~0_combout\);

\inst1|14\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst|1~q\,
	d => \inst1|14~0_combout\,
	clrn => \ALT_INV_inst10~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|14~q\);

\inst1|30\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst1|30~combout\ = (\inst1|11~q\ & \inst1|14~q\)

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100010001000100010001000100010001000100010001000100010001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|ALT_INV_11~q\,
	datab => \inst1|ALT_INV_14~q\,
	combout => \inst1|30~combout\);

\inst1|19\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst|1~q\,
	d => \inst1|30~combout\,
	clrn => \ALT_INV_inst10~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|19~q\);

\inst1|31\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst1|31~combout\ = (!\inst1|11~q\ & !\inst1|19~q\)

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000100010001000100010001000100010001000100010001000100010001000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|ALT_INV_11~q\,
	datab => \inst1|ALT_INV_19~q\,
	combout => \inst1|31~combout\);

\inst1|11\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst|1~q\,
	d => \inst1|31~combout\,
	clrn => \ALT_INV_inst10~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|11~q\);

\inst1|7~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst1|7~0_combout\ = !\inst1|7~q\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101010101010101010101010101010101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|ALT_INV_7~q\,
	combout => \inst1|7~0_combout\);

\inst1|7\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst1|ALT_INV_19~q\,
	d => \inst1|7~0_combout\,
	clrn => \ALT_INV_inst10~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|7~q\);

\QL~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_QL,
	o => \QL~input_o\);

inst10 : cyclonev_lcell_comb
-- Equation(s):
-- \inst10~combout\ = (!\QL~input_o\) # ((!\inst|1~q\ & (\inst1|11~q\ & \inst1|7~q\)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111100000010111111110000001011111111000000101111111100000010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_1~q\,
	datab => \inst1|ALT_INV_11~q\,
	datac => \inst1|ALT_INV_7~q\,
	datad => \ALT_INV_QL~input_o\,
	combout => \inst10~combout\);

\inst|1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CP~input_o\,
	d => \inst|1~0_combout\,
	clrn => \ALT_INV_inst10~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|1~q\);

\inst2|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux0~0_combout\ = (!\inst1|11~q\ & (!\inst1|14~q\ $ (((!\inst|1~q\ & !\inst1|19~q\))))) # (\inst1|11~q\ & (((!\inst1|19~q\))))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111101111000000011110111100000001111011110000000111101111000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_1~q\,
	datab => \inst1|ALT_INV_11~q\,
	datac => \inst1|ALT_INV_14~q\,
	datad => \inst1|ALT_INV_19~q\,
	combout => \inst2|Mux0~0_combout\);

\inst2|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux1~0_combout\ = (!\inst1|14~q\ & (((\inst1|11~q\ & \inst1|19~q\)))) # (\inst1|14~q\ & ((!\inst|1~q\ $ (\inst1|11~q\)) # (\inst1|19~q\)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100100111111000010010011111100001001001111110000100100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_1~q\,
	datab => \inst1|ALT_INV_11~q\,
	datac => \inst1|ALT_INV_14~q\,
	datad => \inst1|ALT_INV_19~q\,
	combout => \inst2|Mux1~0_combout\);

\inst2|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux2~0_combout\ = (!\inst1|14~q\ & (\inst1|11~q\ & ((\inst1|19~q\) # (\inst|1~q\)))) # (\inst1|14~q\ & (((\inst1|19~q\))))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000000111111000100000011111100010000001111110001000000111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_1~q\,
	datab => \inst1|ALT_INV_11~q\,
	datac => \inst1|ALT_INV_14~q\,
	datad => \inst1|ALT_INV_19~q\,
	combout => \inst2|Mux2~0_combout\);

\inst2|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux3~0_combout\ = (!\inst1|11~q\ & (!\inst1|14~q\ $ (((!\inst|1~q\ & !\inst1|19~q\))))) # (\inst1|11~q\ & (!\inst1|19~q\ & ((!\inst1|14~q\) # (\inst|1~q\))))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111100111000000011110011100000001111001110000000111100111000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_1~q\,
	datab => \inst1|ALT_INV_11~q\,
	datac => \inst1|ALT_INV_14~q\,
	datad => \inst1|ALT_INV_19~q\,
	combout => \inst2|Mux3~0_combout\);

\inst2|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux4~0_combout\ = (\inst|1~q\ & ((!\inst1|11~q\ & (!\inst1|14~q\)) # (\inst1|11~q\ & ((!\inst1|19~q\)))))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101000101000000010100010100000001010001010000000101000101000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_1~q\,
	datab => \inst1|ALT_INV_11~q\,
	datac => \inst1|ALT_INV_14~q\,
	datad => \inst1|ALT_INV_19~q\,
	combout => \inst2|Mux4~0_combout\);

\inst2|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux5~0_combout\ = (!\inst|1~q\ & (!\inst1|11~q\ & (!\inst1|14~q\ $ (!\inst1|19~q\)))) # (\inst|1~q\ & ((!\inst1|14~q\ & (!\inst1|11~q\)) # (\inst1|14~q\ & ((!\inst1|19~q\)))))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100110111000000010011011100000001001101110000000100110111000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_1~q\,
	datab => \inst1|ALT_INV_11~q\,
	datac => \inst1|ALT_INV_14~q\,
	datad => \inst1|ALT_INV_19~q\,
	combout => \inst2|Mux5~0_combout\);

\inst2|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux6~0_combout\ = (!\inst1|11~q\ & ((!\inst1|14~q\ $ (!\inst1|19~q\)))) # (\inst1|11~q\ & (!\inst1|19~q\ & ((!\inst1|14~q\) # (\inst|1~q\))))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011110111000000001111011100000000111101110000000011110111000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_1~q\,
	datab => \inst1|ALT_INV_11~q\,
	datac => \inst1|ALT_INV_14~q\,
	datad => \inst1|ALT_INV_19~q\,
	combout => \inst2|Mux6~0_combout\);

\inst|2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|2~0_combout\ = !\inst|2~q\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101010101010101010101010101010101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_2~q\,
	combout => \inst|2~0_combout\);

\inst|2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst1|ALT_INV_7~q\,
	d => \inst|2~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|2~q\);

ww_GW(6) <= \GW[6]~output_o\;

ww_GW(5) <= \GW[5]~output_o\;

ww_GW(4) <= \GW[4]~output_o\;

ww_GW(3) <= \GW[3]~output_o\;

ww_GW(2) <= \GW[2]~output_o\;

ww_GW(1) <= \GW[1]~output_o\;

ww_GW(0) <= \GW[0]~output_o\;

ww_SW(6) <= \SW[6]~output_o\;

ww_SW(5) <= \SW[5]~output_o\;

ww_SW(4) <= \SW[4]~output_o\;

ww_SW(3) <= \SW[3]~output_o\;

ww_SW(2) <= \SW[2]~output_o\;

ww_SW(1) <= \SW[1]~output_o\;

ww_SW(0) <= \SW[0]~output_o\;

ww_SXW(6) <= \SXW[6]~output_o\;

ww_SXW(5) <= \SXW[5]~output_o\;

ww_SXW(4) <= \SXW[4]~output_o\;

ww_SXW(3) <= \SXW[3]~output_o\;

ww_SXW(2) <= \SXW[2]~output_o\;

ww_SXW(1) <= \SXW[1]~output_o\;

ww_SXW(0) <= \SXW[0]~output_o\;
END structure;


