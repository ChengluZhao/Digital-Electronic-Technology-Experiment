-- Copyright (C) 2017  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Intel and sold by Intel or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 17.0.0 Build 595 04/25/2017 SJ Lite Edition"

-- DATE "04/25/2024 21:49:46"

-- 
-- Device: Altera 5CSEMA5F31C6 Package FBGA896
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY ALTERA_LNSIM;
LIBRARY CYCLONEV;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE ALTERA_LNSIM.ALTERA_LNSIM_COMPONENTS.ALL;
USE CYCLONEV.CYCLONEV_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	cd40422 IS
    PORT (
	D1 : IN std_logic;
	D2 : IN std_logic;
	D3 : IN std_logic;
	D4 : IN std_logic;
	M : IN std_logic;
	CP : IN std_logic;
	Q1 : OUT std_logic;
	Q2 : OUT std_logic;
	Q3 : OUT std_logic;
	Q4 : OUT std_logic;
	NQ1 : OUT std_logic;
	NQ2 : OUT std_logic;
	NQ3 : OUT std_logic;
	NQ4 : OUT std_logic
	);
END cd40422;

-- Design Ports Information
-- Q1	=>  Location: PIN_AA28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Q2	=>  Location: PIN_AA26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Q3	=>  Location: PIN_AC29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Q4	=>  Location: PIN_Y26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- NQ1	=>  Location: PIN_AB30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- NQ2	=>  Location: PIN_AE29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- NQ3	=>  Location: PIN_V25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- NQ4	=>  Location: PIN_AD30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D1	=>  Location: PIN_AB28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D2	=>  Location: PIN_AB27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D3	=>  Location: PIN_AA30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D4	=>  Location: PIN_AC30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- CP	=>  Location: PIN_Y27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M	=>  Location: PIN_AD29,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF cd40422 IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_D1 : std_logic;
SIGNAL ww_D2 : std_logic;
SIGNAL ww_D3 : std_logic;
SIGNAL ww_D4 : std_logic;
SIGNAL ww_M : std_logic;
SIGNAL ww_CP : std_logic;
SIGNAL ww_Q1 : std_logic;
SIGNAL ww_Q2 : std_logic;
SIGNAL ww_Q3 : std_logic;
SIGNAL ww_Q4 : std_logic;
SIGNAL ww_NQ1 : std_logic;
SIGNAL ww_NQ2 : std_logic;
SIGNAL ww_NQ3 : std_logic;
SIGNAL ww_NQ4 : std_logic;
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \D1~input_o\ : std_logic;
SIGNAL \M~input_o\ : std_logic;
SIGNAL \CP~input_o\ : std_logic;
SIGNAL \Equal0~0_combout\ : std_logic;
SIGNAL \X[3]~1_combout\ : std_logic;
SIGNAL \CP~inputCLKENA0_outclk\ : std_logic;
SIGNAL \X[3]~3_combout\ : std_logic;
SIGNAL \X[3]~_emulated_q\ : std_logic;
SIGNAL \X[3]~2_combout\ : std_logic;
SIGNAL \D2~input_o\ : std_logic;
SIGNAL \X[2]~5_combout\ : std_logic;
SIGNAL \X[2]~7_combout\ : std_logic;
SIGNAL \X[2]~_emulated_q\ : std_logic;
SIGNAL \X[2]~6_combout\ : std_logic;
SIGNAL \D3~input_o\ : std_logic;
SIGNAL \X[1]~9_combout\ : std_logic;
SIGNAL \X[1]~11_combout\ : std_logic;
SIGNAL \X[1]~_emulated_q\ : std_logic;
SIGNAL \X[1]~10_combout\ : std_logic;
SIGNAL \D4~input_o\ : std_logic;
SIGNAL \X[0]~13_combout\ : std_logic;
SIGNAL \X[0]~15_combout\ : std_logic;
SIGNAL \X[0]~_emulated_q\ : std_logic;
SIGNAL \X[0]~14_combout\ : std_logic;
SIGNAL \ALT_INV_X[3]~_emulated_q\ : std_logic;
SIGNAL \ALT_INV_X[3]~2_combout\ : std_logic;
SIGNAL \ALT_INV_X[2]~_emulated_q\ : std_logic;
SIGNAL \ALT_INV_X[2]~6_combout\ : std_logic;
SIGNAL \ALT_INV_X[1]~_emulated_q\ : std_logic;
SIGNAL \ALT_INV_X[1]~10_combout\ : std_logic;
SIGNAL \ALT_INV_X[0]~_emulated_q\ : std_logic;
SIGNAL \ALT_INV_X[0]~14_combout\ : std_logic;
SIGNAL \ALT_INV_Equal0~0_combout\ : std_logic;
SIGNAL \ALT_INV_X[3]~1_combout\ : std_logic;
SIGNAL \ALT_INV_CP~input_o\ : std_logic;
SIGNAL \ALT_INV_M~input_o\ : std_logic;
SIGNAL \ALT_INV_CP~inputCLKENA0_outclk\ : std_logic;
SIGNAL \ALT_INV_X[2]~5_combout\ : std_logic;
SIGNAL \ALT_INV_X[1]~9_combout\ : std_logic;
SIGNAL \ALT_INV_X[0]~13_combout\ : std_logic;
SIGNAL \ALT_INV_D2~input_o\ : std_logic;
SIGNAL \ALT_INV_D1~input_o\ : std_logic;
SIGNAL \ALT_INV_D3~input_o\ : std_logic;
SIGNAL \ALT_INV_D4~input_o\ : std_logic;

BEGIN

ww_D1 <= D1;
ww_D2 <= D2;
ww_D3 <= D3;
ww_D4 <= D4;
ww_M <= M;
ww_CP <= CP;
Q1 <= ww_Q1;
Q2 <= ww_Q2;
Q3 <= ww_Q3;
Q4 <= ww_Q4;
NQ1 <= ww_NQ1;
NQ2 <= ww_NQ2;
NQ3 <= ww_NQ3;
NQ4 <= ww_NQ4;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
\ALT_INV_X[3]~_emulated_q\ <= NOT \X[3]~_emulated_q\;
\ALT_INV_X[3]~2_combout\ <= NOT \X[3]~2_combout\;
\ALT_INV_X[2]~_emulated_q\ <= NOT \X[2]~_emulated_q\;
\ALT_INV_X[2]~6_combout\ <= NOT \X[2]~6_combout\;
\ALT_INV_X[1]~_emulated_q\ <= NOT \X[1]~_emulated_q\;
\ALT_INV_X[1]~10_combout\ <= NOT \X[1]~10_combout\;
\ALT_INV_X[0]~_emulated_q\ <= NOT \X[0]~_emulated_q\;
\ALT_INV_X[0]~14_combout\ <= NOT \X[0]~14_combout\;
\ALT_INV_Equal0~0_combout\ <= NOT \Equal0~0_combout\;
\ALT_INV_X[3]~1_combout\ <= NOT \X[3]~1_combout\;
\ALT_INV_CP~input_o\ <= NOT \CP~input_o\;
\ALT_INV_M~input_o\ <= NOT \M~input_o\;
\ALT_INV_CP~inputCLKENA0_outclk\ <= NOT \CP~inputCLKENA0_outclk\;
\ALT_INV_X[2]~5_combout\ <= NOT \X[2]~5_combout\;
\ALT_INV_X[1]~9_combout\ <= NOT \X[1]~9_combout\;
\ALT_INV_X[0]~13_combout\ <= NOT \X[0]~13_combout\;
\ALT_INV_D2~input_o\ <= NOT \D2~input_o\;
\ALT_INV_D1~input_o\ <= NOT \D1~input_o\;
\ALT_INV_D3~input_o\ <= NOT \D3~input_o\;
\ALT_INV_D4~input_o\ <= NOT \D4~input_o\;

-- Location: IOOBUF_X89_Y21_N56
\Q1~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \X[3]~2_combout\,
	devoe => ww_devoe,
	o => ww_Q1);

-- Location: IOOBUF_X89_Y23_N5
\Q2~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \X[2]~6_combout\,
	devoe => ww_devoe,
	o => ww_Q2);

-- Location: IOOBUF_X89_Y20_N96
\Q3~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \X[1]~10_combout\,
	devoe => ww_devoe,
	o => ww_Q3);

-- Location: IOOBUF_X89_Y25_N5
\Q4~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \X[0]~14_combout\,
	devoe => ww_devoe,
	o => ww_Q4);

-- Location: IOOBUF_X89_Y21_N5
\NQ1~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_X[3]~2_combout\,
	devoe => ww_devoe,
	o => ww_NQ1);

-- Location: IOOBUF_X89_Y23_N39
\NQ2~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_X[2]~6_combout\,
	devoe => ww_devoe,
	o => ww_NQ2);

-- Location: IOOBUF_X89_Y20_N62
\NQ3~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_X[1]~10_combout\,
	devoe => ww_devoe,
	o => ww_NQ3);

-- Location: IOOBUF_X89_Y25_N39
\NQ4~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_X[0]~14_combout\,
	devoe => ww_devoe,
	o => ww_NQ4);

-- Location: IOIBUF_X89_Y21_N38
\D1~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D1,
	o => \D1~input_o\);

-- Location: IOIBUF_X89_Y23_N55
\M~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M,
	o => \M~input_o\);

-- Location: IOIBUF_X89_Y25_N21
\CP~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CP,
	o => \CP~input_o\);

-- Location: LABCELL_X88_Y25_N24
\Equal0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \Equal0~0_combout\ = ( \CP~input_o\ & ( \M~input_o\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \ALT_INV_M~input_o\,
	dataf => \ALT_INV_CP~input_o\,
	combout => \Equal0~0_combout\);

-- Location: LABCELL_X88_Y25_N21
\X[3]~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \X[3]~1_combout\ = ( \Equal0~0_combout\ & ( \D1~input_o\ ) ) # ( !\Equal0~0_combout\ & ( \X[3]~1_combout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000001111111100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_D1~input_o\,
	datad => \ALT_INV_X[3]~1_combout\,
	dataf => \ALT_INV_Equal0~0_combout\,
	combout => \X[3]~1_combout\);

-- Location: CLKCTRL_G10
\CP~inputCLKENA0\ : cyclonev_clkena
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	disable_mode => "low",
	ena_register_mode => "always enabled",
	ena_register_power_up => "high",
	test_syn => "high")
-- pragma translate_on
PORT MAP (
	inclk => \CP~input_o\,
	outclk => \CP~inputCLKENA0_outclk\);

-- Location: LABCELL_X88_Y25_N18
\X[3]~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \X[3]~3_combout\ = !\D1~input_o\ $ (!\X[3]~1_combout\)

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011110000111100001111000011110000111100001111000011110000111100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_D1~input_o\,
	datac => \ALT_INV_X[3]~1_combout\,
	combout => \X[3]~3_combout\);

-- Location: FF_X88_Y25_N20
\X[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_CP~inputCLKENA0_outclk\,
	d => \X[3]~3_combout\,
	clrn => \ALT_INV_Equal0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \X[3]~_emulated_q\);

-- Location: LABCELL_X88_Y25_N3
\X[3]~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \X[3]~2_combout\ = ( \X[3]~_emulated_q\ & ( (!\Equal0~0_combout\ & (!\X[3]~1_combout\)) # (\Equal0~0_combout\ & ((\D1~input_o\))) ) ) # ( !\X[3]~_emulated_q\ & ( (!\Equal0~0_combout\ & (\X[3]~1_combout\)) # (\Equal0~0_combout\ & ((\D1~input_o\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100010001110111010001000111011110001000101110111000100010111011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_X[3]~1_combout\,
	datab => \ALT_INV_Equal0~0_combout\,
	datad => \ALT_INV_D1~input_o\,
	dataf => \ALT_INV_X[3]~_emulated_q\,
	combout => \X[3]~2_combout\);

-- Location: IOIBUF_X89_Y23_N21
\D2~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D2,
	o => \D2~input_o\);

-- Location: LABCELL_X88_Y25_N42
\X[2]~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \X[2]~5_combout\ = ( \Equal0~0_combout\ & ( \D2~input_o\ ) ) # ( !\Equal0~0_combout\ & ( \X[2]~5_combout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_X[2]~5_combout\,
	datac => \ALT_INV_D2~input_o\,
	dataf => \ALT_INV_Equal0~0_combout\,
	combout => \X[2]~5_combout\);

-- Location: LABCELL_X88_Y25_N27
\X[2]~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \X[2]~7_combout\ = ( \X[2]~5_combout\ & ( !\D2~input_o\ ) ) # ( !\X[2]~5_combout\ & ( \D2~input_o\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010110101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_D2~input_o\,
	dataf => \ALT_INV_X[2]~5_combout\,
	combout => \X[2]~7_combout\);

-- Location: FF_X88_Y25_N29
\X[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_CP~inputCLKENA0_outclk\,
	d => \X[2]~7_combout\,
	clrn => \ALT_INV_Equal0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \X[2]~_emulated_q\);

-- Location: LABCELL_X88_Y25_N6
\X[2]~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \X[2]~6_combout\ = ( \D2~input_o\ & ( (!\X[2]~_emulated_q\ $ (!\X[2]~5_combout\)) # (\Equal0~0_combout\) ) ) # ( !\D2~input_o\ & ( (!\Equal0~0_combout\ & (!\X[2]~_emulated_q\ $ (!\X[2]~5_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110011000000000011001100000000111111111100110011111111110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_Equal0~0_combout\,
	datac => \ALT_INV_X[2]~_emulated_q\,
	datad => \ALT_INV_X[2]~5_combout\,
	dataf => \ALT_INV_D2~input_o\,
	combout => \X[2]~6_combout\);

-- Location: IOIBUF_X89_Y21_N21
\D3~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D3,
	o => \D3~input_o\);

-- Location: LABCELL_X88_Y25_N12
\X[1]~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \X[1]~9_combout\ = ( \Equal0~0_combout\ & ( \D3~input_o\ ) ) # ( !\Equal0~0_combout\ & ( \X[1]~9_combout\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_X[1]~9_combout\,
	datac => \ALT_INV_D3~input_o\,
	dataf => \ALT_INV_Equal0~0_combout\,
	combout => \X[1]~9_combout\);

-- Location: LABCELL_X88_Y25_N45
\X[1]~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \X[1]~11_combout\ = ( \X[1]~9_combout\ & ( !\D3~input_o\ ) ) # ( !\X[1]~9_combout\ & ( \D3~input_o\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010110101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_D3~input_o\,
	dataf => \ALT_INV_X[1]~9_combout\,
	combout => \X[1]~11_combout\);

-- Location: FF_X88_Y25_N47
\X[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_CP~inputCLKENA0_outclk\,
	d => \X[1]~11_combout\,
	clrn => \ALT_INV_Equal0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \X[1]~_emulated_q\);

-- Location: LABCELL_X88_Y25_N9
\X[1]~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \X[1]~10_combout\ = ( \X[1]~9_combout\ & ( (!\Equal0~0_combout\ & (!\X[1]~_emulated_q\)) # (\Equal0~0_combout\ & ((\D3~input_o\))) ) ) # ( !\X[1]~9_combout\ & ( (!\Equal0~0_combout\ & (\X[1]~_emulated_q\)) # (\Equal0~0_combout\ & ((\D3~input_o\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110000111111000011000011111111000000111100111100000011110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_Equal0~0_combout\,
	datac => \ALT_INV_X[1]~_emulated_q\,
	datad => \ALT_INV_D3~input_o\,
	dataf => \ALT_INV_X[1]~9_combout\,
	combout => \X[1]~10_combout\);

-- Location: IOIBUF_X89_Y25_N55
\D4~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D4,
	o => \D4~input_o\);

-- Location: LABCELL_X88_Y25_N0
\X[0]~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \X[0]~13_combout\ = (!\Equal0~0_combout\ & ((\X[0]~13_combout\))) # (\Equal0~0_combout\ & (\D4~input_o\))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001111001111000000111100111100000011110011110000001111001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_Equal0~0_combout\,
	datac => \ALT_INV_D4~input_o\,
	datad => \ALT_INV_X[0]~13_combout\,
	combout => \X[0]~13_combout\);

-- Location: LABCELL_X88_Y25_N15
\X[0]~15\ : cyclonev_lcell_comb
-- Equation(s):
-- \X[0]~15_combout\ = ( \X[0]~13_combout\ & ( !\D4~input_o\ ) ) # ( !\X[0]~13_combout\ & ( \D4~input_o\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010110101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_D4~input_o\,
	dataf => \ALT_INV_X[0]~13_combout\,
	combout => \X[0]~15_combout\);

-- Location: FF_X88_Y25_N17
\X[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_CP~inputCLKENA0_outclk\,
	d => \X[0]~15_combout\,
	clrn => \ALT_INV_Equal0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \X[0]~_emulated_q\);

-- Location: LABCELL_X88_Y25_N54
\X[0]~14\ : cyclonev_lcell_comb
-- Equation(s):
-- \X[0]~14_combout\ = ( \D4~input_o\ & ( \Equal0~0_combout\ ) ) # ( \D4~input_o\ & ( !\Equal0~0_combout\ & ( !\X[0]~_emulated_q\ $ (!\X[0]~13_combout\) ) ) ) # ( !\D4~input_o\ & ( !\Equal0~0_combout\ & ( !\X[0]~_emulated_q\ $ (!\X[0]~13_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011110000111100001111000011110000000000000000001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_X[0]~_emulated_q\,
	datac => \ALT_INV_X[0]~13_combout\,
	datae => \ALT_INV_D4~input_o\,
	dataf => \ALT_INV_Equal0~0_combout\,
	combout => \X[0]~14_combout\);

-- Location: LABCELL_X56_Y9_N0
\~QUARTUS_CREATED_GND~I\ : cyclonev_lcell_comb
-- Equation(s):

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
;
END structure;


