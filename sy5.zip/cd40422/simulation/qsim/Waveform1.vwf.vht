-- Copyright (C) 2017  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Intel and sold by Intel or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- *****************************************************************************
-- This file contains a Vhdl test bench with test vectors .The test vectors     
-- are exported from a vector file in the Quartus Waveform Editor and apply to  
-- the top level entity of the current Quartus project .The user can use this   
-- testbench to simulate his design using a third-party simulation tool .       
-- *****************************************************************************
-- Generated on "04/25/2024 21:49:45"
                                                             
-- Vhdl Test Bench(with test vectors) for design  :          cd40422
-- 
-- Simulation tool : 3rd Party
-- 

LIBRARY ieee;                                               
USE ieee.std_logic_1164.all;                                

ENTITY cd40422_vhd_vec_tst IS
END cd40422_vhd_vec_tst;
ARCHITECTURE cd40422_arch OF cd40422_vhd_vec_tst IS
-- constants                                                 
-- signals                                                   
SIGNAL CP : STD_LOGIC;
SIGNAL D1 : STD_LOGIC;
SIGNAL D2 : STD_LOGIC;
SIGNAL D3 : STD_LOGIC;
SIGNAL D4 : STD_LOGIC;
SIGNAL M : STD_LOGIC;
SIGNAL NQ1 : STD_LOGIC;
SIGNAL NQ2 : STD_LOGIC;
SIGNAL NQ3 : STD_LOGIC;
SIGNAL NQ4 : STD_LOGIC;
SIGNAL Q1 : STD_LOGIC;
SIGNAL Q2 : STD_LOGIC;
SIGNAL Q3 : STD_LOGIC;
SIGNAL Q4 : STD_LOGIC;
COMPONENT cd40422
	PORT (
	CP : IN STD_LOGIC;
	D1 : IN STD_LOGIC;
	D2 : IN STD_LOGIC;
	D3 : IN STD_LOGIC;
	D4 : IN STD_LOGIC;
	M : IN STD_LOGIC;
	NQ1 : OUT STD_LOGIC;
	NQ2 : OUT STD_LOGIC;
	NQ3 : OUT STD_LOGIC;
	NQ4 : OUT STD_LOGIC;
	Q1 : OUT STD_LOGIC;
	Q2 : OUT STD_LOGIC;
	Q3 : OUT STD_LOGIC;
	Q4 : OUT STD_LOGIC
	);
END COMPONENT;
BEGIN
	i1 : cd40422
	PORT MAP (
-- list connections between master ports and signals
	CP => CP,
	D1 => D1,
	D2 => D2,
	D3 => D3,
	D4 => D4,
	M => M,
	NQ1 => NQ1,
	NQ2 => NQ2,
	NQ3 => NQ3,
	NQ4 => NQ4,
	Q1 => Q1,
	Q2 => Q2,
	Q3 => Q3,
	Q4 => Q4
	);

-- CP
t_prcs_CP: PROCESS
BEGIN
	CP <= '0';
WAIT;
END PROCESS t_prcs_CP;

-- D1
t_prcs_D1: PROCESS
BEGIN
	D1 <= '1';
WAIT;
END PROCESS t_prcs_D1;

-- D2
t_prcs_D2: PROCESS
BEGIN
	D2 <= '0';
WAIT;
END PROCESS t_prcs_D2;

-- D3
t_prcs_D3: PROCESS
BEGIN
	D3 <= '0';
WAIT;
END PROCESS t_prcs_D3;

-- D4
t_prcs_D4: PROCESS
BEGIN
	D4 <= '0';
WAIT;
END PROCESS t_prcs_D4;

-- M
t_prcs_M: PROCESS
BEGIN
	M <= '0';
WAIT;
END PROCESS t_prcs_M;
END cd40422_arch;
