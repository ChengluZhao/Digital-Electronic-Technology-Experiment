LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;

ENTITY yimaqi0_9 IS
PORT (LT,RBI,BI: IN STD_LOGIC;--输入控制端：LT灯测试端、RBI消隐输入端脉冲、BI消隐输入端
		D,C,B,A: IN STD_LOGIC;--译码地址输入端：D高--A低
		Q:OUT STD_LOGIC_VECTOR(6 DOWNTO 0));--段输出：6543210对应abcdefg
END ENTITY yimaqi0_9;

ARCHITECTURE RTL OF yimaqi0_9 IS
SIGNAL M:STD_LOGIC_VECTOR(6 DOWNTO 0);
SIGNAL N:STD_LOGIC_VECTOR(3 DOWNTO 0);
BEGIN
	N<=D&C&B&A;
   PROCESS(LT,RBI,BI,N)
	BEGIN
	   IF(BI='0' OR RBI='0') THEN--消隐时低电平有效，全灭
		   M<="1111111";
		ELSIF(LT='0' ) THEN--灯测试时低电平效，全亮8
		   M<="0000000";
		ELSE
		CASE N IS
			WHEN "0000" => M<="0000001";--对应数码管0
			WHEN "0001" => M<="1001111";--对应数码管1
			WHEN "0010" => M<="0010010";--对应数码管2
			WHEN "0011" => M<="0000110";--对应数码管3
			WHEN "0100" => M<="1001100";--对应数码管4
			WHEN "0101" => M<="0100100";--对应数码管5
			WHEN "0110" => M<="0100000";--对应数码管6
			WHEN "0111" => M<="0001111";--对应数码管7
			WHEN "1000" => M<="0000000";--对应数码管8
			WHEN "1001" => M<="0000100";--对应数码管9
			WHEN OTHERS => M<="1111111";--超过9后不显示
		END CASE;
		END IF;
		Q<=M;
	END PROCESS;
END ARCHITECTURE RTL;
